/**
 * Can Yapı Antalya - Ana JavaScript Dosyası (Main Logic)
 * Mobil navigasyon, teklif modalı, dosya yükleme önizlemesi,
 * form doğrulama, talep saklama ve etkileşimler.
 */

// İletişim & Sosyal Medya Sabitleri (Buradan kolayca güncellenebilir)
const CAN_YAPI_CONFIG = {
  phone: "+90 545 832 01 90",
  phoneRaw: "+905458320190",
  whatsapp: "905458320190",
  email: "info@canyapiantalya.com",
  address: "Muratpaşa, Antalya / Türkiye",
  // Sosyal Medya Hesapları (Admin panelinden veya buradan güncellenebilir)
  social: {
    instagram: "", // Örn: "https://instagram.com/canyapiantalya"
    facebook: "",  // Örn: "https://facebook.com/canyapiantalya"
    tiktok: "",    // Örn: "https://tiktok.com/@canyapiantalya"
    x: "",         // Örn: "https://x.com/canyapiantalya"
    youtube: ""    // Örn: "https://youtube.com/@canyapiantalya"
  }
};

document.addEventListener('DOMContentLoaded', function() {
  initTheme();
  initHeader();
  initMobileNav();
  syncContactLinks();
  initSocialLinks();
  initQuoteModal();
  initForms();
  initCounters();
  initGalleryLightbox();
  initDynamicCmsContent();
});

/* ==========================================================================
   THEME SWITCHER (Koyu Siyah / Açık Beyaz)
   ========================================================================== */
function initTheme() {
  const savedTheme = localStorage.getItem('canyapi_theme') || 'dark';
  applyTheme(savedTheme);

  document.querySelectorAll('.js-theme-toggle').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      const newTheme = currentTheme === 'light' ? 'dark' : 'light';
      applyTheme(newTheme);
      localStorage.setItem('canyapi_theme', newTheme);
    });
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  if (document.body) {
    document.body.classList.toggle('light-theme', theme === 'light');
  }
  const toggleBtns = document.querySelectorAll('.js-theme-toggle');
  toggleBtns.forEach(btn => {
    if (theme === 'light') {
      btn.innerHTML = '🌙 <span>Koyu</span>';
      btn.setAttribute('title', 'Koyu Temaya Geç');
    } else {
      btn.innerHTML = '☀️ <span>Açık</span>';
      btn.setAttribute('title', 'Açık Temaya Geç');
    }
  });
}


/* ==========================================================================
   HEADER SCROLL & MOBIL MENU
   ========================================================================== */
function initHeader() {
  const header = document.querySelector('.header');
  if (!header) return;

  window.addEventListener('scroll', function() {
    if (window.scrollY > 40) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
}

function initMobileNav() {
  const hamburgerBtns = document.querySelectorAll('.hamburger-btn, .mobile-toggle, .js-mobile-toggle');
  const closeBtns = document.querySelectorAll('.mobile-close-btn, .js-mobile-close');
  const overlay = document.querySelector('.mobile-nav-overlay');
  const drawer = document.querySelector('.mobile-nav-drawer');
  const servicesToggle = document.querySelector('.js-mobile-services-toggle');
  const submenu = document.querySelector('.mobile-submenu');

  function openMenu(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (drawer && overlay) {
      drawer.classList.add('open');
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeMenu(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (drawer && overlay) {
      drawer.classList.remove('open');
      overlay.classList.remove('open');
      document.body.style.overflow = '';
    }
  }

  hamburgerBtns.forEach(btn => btn.addEventListener('click', openMenu));
  closeBtns.forEach(btn => btn.addEventListener('click', closeMenu));
  if (overlay) overlay.addEventListener('click', closeMenu);

  document.querySelectorAll('.mobile-nav-link:not(.js-mobile-services-toggle)').forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  if (servicesToggle && submenu) {
    servicesToggle.addEventListener('click', function(e) {
      e.preventDefault();
      submenu.classList.toggle('open');
    });
  }
}

/* ==========================================================================
   QUOTE / FREE DISCOVERY MODAL LOGIC (Evrensel Dinamik Modal)
   ========================================================================== */
let selectedFilesStore = [];

function ensureQuoteModalExists() {
  let modalOverlay = document.getElementById('quoteModal');
  if (modalOverlay) return modalOverlay;

  modalOverlay = document.createElement('div');
  modalOverlay.className = 'modal-overlay';
  modalOverlay.id = 'quoteModal';
  modalOverlay.innerHTML = `
    <div class="modal-card">
      <button class="modal-close-btn" id="modalCloseBtn" aria-label="Kapat">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>

      <div style="margin-bottom: 24px;">
        <div class="section-tag">Hızlı Çözüm</div>
        <h3 id="modalTitle" style="font-size: 1.6rem; color: #FFF; margin-bottom: 6px;">Hemen Teklif Alın</h3>
        <p class="text-muted" style="font-size: 0.9rem;">Formu doldurun, projenize en uygun fiyatlandırmayı hazırlayalım.</p>
      </div>

      <form class="js-quote-form" enctype="multipart/form-data">
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">Adınız Soyadınız <span class="required">*</span></label>
            <input type="text" name="name" class="form-control" placeholder="Ad Soyad" required>
          </div>

          <div class="form-group">
            <label class="form-label">Telefon Numaranız <span class="required">*</span></label>
            <input type="tel" name="phone" class="form-control" placeholder="05XX XXX XX XX" required>
          </div>

          <div class="form-group">
            <label class="form-label">Hizmet Türü <span class="required">*</span></label>
            <select name="service" id="modalServiceSelect" class="form-control" required>
              <option value="">Hizmet Seçiniz</option>
              <option value="Mutfak Tadilatı">Mutfak Tadilatı</option>
              <option value="Banyo Tadilatı">Banyo Tadilatı & Islak Zemin</option>
              <option value="Seramik ve Fayans">Seramik ve Fayans</option>
              <option value="Boya ve Badana">Boya, Badana & Alçı</option>
              <option value="Mantolama ve Yalıtım">Dış Cephe Mantolama & Yalıtım</option>
              <option value="Çatı ve İzolasyon">Çatı Onarımı & İzolasyon</option>
              <option value="Komple Ev Tadilatı">Komple Ev / Villa Tadilatı</option>
              <option value="Prefabrik Yapı">Prefabrik Yapı & Çelik Ev</option>
              <option value="Genel Teklif">Diğer / Genel Keşif</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Konum (Antalya İlçesi)</label>
            <select name="location" class="form-control">
              <option value="Muratpaşa">Muratpaşa</option>
              <option value="Konyaaltı">Konyaaltı</option>
              <option value="Kepez">Kepez</option>
              <option value="Döşemealtı">Döşemealtı</option>
              <option value="Alanya">Alanya</option>
              <option value="Manavgat">Manavgat</option>
              <option value="Kemer">Kemer</option>
              <option value="Serik / Belek">Serik / Belek</option>
              <option value="Diğer">Diğer İlçe</option>
            </select>
          </div>

          <div class="form-group full-width">
            <label class="form-label">Proje Açıklaması</label>
            <textarea name="notes" class="form-control" style="min-height: 80px;" placeholder="Yapılacak işler, yaklaşık ölçü veya istekleriniz..."></textarea>
          </div>

          <!-- Dosya Yükleme -->
          <div class="form-group full-width">
            <label class="form-label">Fotoğraf Yükleyin (İsteğe Bağlı)</label>
            <div class="file-upload-box" id="modalUploadBox" style="padding: 16px;">
              <input type="file" id="modalFileInput" multiple accept="image/jpeg,image/png,image/webp,.pdf">
              <div class="upload-text" style="font-size: 0.82rem;">Fotoğrafları buraya sürükleyin veya tıklayarak seçin</div>
            </div>
            <div class="file-preview-list" id="modalFilePreview"></div>
          </div>

          <div class="form-group full-width">
            <label class="checkbox-wrap">
              <input type="checkbox" name="discovery" id="modalDiscoveryCheck">
              <span><strong>Ücretsiz keşif istiyorum.</strong> Uzmanınız adresime gelerek inceleme yapsın.</span>
            </label>
          </div>

          <div class="form-group full-width" style="margin-top: 10px;">
            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 14px;">
              <span>Teklifi Gönder & Keşif İste</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(modalOverlay);
  return modalOverlay;
}

function initQuoteModal() {
  const modalOverlay = ensureQuoteModalExists();
  const modalCloseBtn = modalOverlay.querySelector('#modalCloseBtn');
  const triggerBtns = document.querySelectorAll('.js-open-quote-modal');

  triggerBtns.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const service = this.getAttribute('data-service') || '';
      const isDiscovery = this.getAttribute('data-discovery') === 'true';
      openQuoteModal(service, isDiscovery);
    });
  });

  if (modalCloseBtn && modalOverlay) {
    modalCloseBtn.addEventListener('click', closeQuoteModal);
    modalOverlay.addEventListener('click', function(e) {
      if (e.target === modalOverlay) closeQuoteModal();
    });
  }

  // ESC tuşu ile kapatma
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeQuoteModal();
  });

  // Dosya Yükleme Alanı
  initFileUpload('modalFileInput', 'modalUploadBox', 'modalFilePreview');
}

window.openQuoteModal = function(serviceName = '', isDiscovery = false) {
  const modalOverlay = ensureQuoteModalExists();
  if (!modalOverlay) return;

  const serviceSelect = document.getElementById('modalServiceSelect');
  const discoveryCheckbox = document.getElementById('modalDiscoveryCheck');
  const modalTitle = document.getElementById('modalTitle');

  if (serviceSelect && serviceName) {
    serviceSelect.value = serviceName;
  }

  if (discoveryCheckbox) {
    discoveryCheckbox.checked = isDiscovery;
  }

  if (modalTitle) {
    modalTitle.innerText = isDiscovery ? 'Ücretsiz Keşif & Randevu Talebi' : 'Hemen Teklif Alın';
  }

  modalOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';

  // Analytics tetikle
  if (window.CanYapiAnalytics) {
    if (isDiscovery) {
      window.CanYapiAnalytics.track('free_discovery_click', { service: serviceName || 'Genel' });
    }
  }
};

window.closeQuoteModal = function() {
  const modalOverlay = document.getElementById('quoteModal');
  if (modalOverlay) {
    modalOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }
};

/* ==========================================================================
   İLETİŞİM BAĞLANTILARI SENKRONİZASYONU (Telefon & WhatsApp)
   ========================================================================== */
function syncContactLinks() {
  // 1. Tüm tel: bağlantılarını CAN_YAPI_CONFIG'e senkronize et
  document.querySelectorAll('a[href^="tel:"]').forEach(link => {
    link.href = `tel:${CAN_YAPI_CONFIG.phoneRaw}`;
  });

  // 2. Belirtilen özel telefon metinlerini güncelle
  document.querySelectorAll('.js-contact-phone').forEach(el => {
    el.textContent = CAN_YAPI_CONFIG.phone;
  });

  // 3. WhatsApp linklerinin numara kısmını doğrula ve güncelle
  document.querySelectorAll('a[href*="wa.me"]').forEach(link => {
    try {
      const url = new URL(link.href);
      const query = url.search; // Varsa ?text=... kısmını koru
      link.href = `https://wa.me/${CAN_YAPI_CONFIG.whatsapp}${query}`;
    } catch (e) {
      // Düz metin bağlantısı
      const parts = link.href.split('?');
      const query = parts.length > 1 ? '?' + parts[1] : '';
      link.href = `https://wa.me/${CAN_YAPI_CONFIG.whatsapp}${query}`;
    }
  });
}

/* ==========================================================================
   SOSYAL MEDYA BAĞLANTILARI ALTYAPISI (Admin Paneli ile Entegre)
   ========================================================================== */
function getActiveSocialLinks() {
  try {
    const stored = localStorage.getItem('canyapi_social_links');
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...CAN_YAPI_CONFIG.social, ...parsed };
    }
  } catch (e) {
    console.warn('Sosyal medya verisi okuma hatası:', e);
  }
  return CAN_YAPI_CONFIG.social || {};
}

function initSocialLinks() {
  const containers = document.querySelectorAll('.footer-social-links, #footerSocialLinks');
  if (!containers.length) return;

  const social = getActiveSocialLinks();
  const activePlatforms = [];

  const icons = {
    instagram: `<svg viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>`,
    facebook: `<svg viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>`,
    tiktok: `<svg viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.86.12V9.42a6.27 6.27 0 0 0-.86-.06 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.28 8.28 0 0 0 4.84 1.55V6.86a4.85 4.85 0 0 1-1.07-.17z"/></svg>`,
    x: `<svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>`,
    youtube: `<svg viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>`
  };

  const titles = {
    instagram: 'Instagram',
    facebook: 'Facebook',
    tiktok: 'TikTok',
    x: 'X (Twitter)',
    youtube: 'YouTube'
  };

  Object.keys(social).forEach(key => {
    const url = (social[key] || '').trim();
    if (url) {
      activePlatforms.push({
        platform: key,
        url: url,
        title: titles[key] || key.charAt(0).toUpperCase() + key.slice(1),
        svg: icons[key] || ''
      });
    }
  });

  // Eğer hiçbir link tanımlı değilse konteyner boş kalır (CSS :empty kuralı ile görünmez)
  containers.forEach(container => {
    container.innerHTML = '';
    if (activePlatforms.length > 0) {
      activePlatforms.forEach(item => {
        const link = document.createElement('a');
        link.href = item.url;
        link.className = 'social-icon-btn';
        link.setAttribute('target', '_blank');
        link.setAttribute('rel', 'noopener noreferrer');
        link.setAttribute('aria-label', `Can Yapı ${item.title}`);
        link.setAttribute('title', `Can Yapı ${item.title}`);
        link.innerHTML = item.svg;
        container.appendChild(link);
      });
    }
  });
}

window.initSocialLinks = initSocialLinks;

/* ==========================================================================
   FILE UPLOAD & PREVIEW (Fotoğraf Yükleme Desteği)
   ========================================================================== */
function initFileUpload(inputId, boxId, previewId) {
  const input = document.getElementById(inputId);
  const box = document.getElementById(boxId);
  const preview = document.getElementById(previewId);

  if (!input || !box || !preview) return;

  box.addEventListener('dragover', function(e) {
    e.preventDefault();
    box.classList.add('dragover');
  });

  box.addEventListener('dragleave', function() {
    box.classList.remove('dragover');
  });

  box.addEventListener('drop', function(e) {
    e.preventDefault();
    box.classList.remove('dragover');
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files, preview);
    }
  });

  input.addEventListener('change', function() {
    if (input.files && input.files.length > 0) {
      handleFiles(input.files, preview);
    }
  });
}

function handleFiles(files, previewElement) {
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    // Sadece resim ve pdf dosyalarını kabul et
    if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
      showToast('Lütfen yalnızca fotoğraf veya PDF dosyası yükleyin.', 'error');
      continue;
    }

    selectedFilesStore.push({
      name: file.name,
      size: (file.size / 1024 / 1024).toFixed(2) + ' MB'
    });

    renderPreviews(previewElement);
  }
}

function renderPreviews(previewElement) {
  previewElement.innerHTML = '';
  selectedFilesStore.forEach((f, idx) => {
    const chip = document.createElement('div');
    chip.className = 'preview-chip';
    chip.innerHTML = `
      <span>📎 ${f.name} (${f.size})</span>
      <span class="remove-file" onclick="removeSelectedFile(${idx}, '${previewElement.id}')">&times;</span>
    `;
    previewElement.appendChild(chip);
  });
}

window.removeSelectedFile = function(index, previewId) {
  selectedFilesStore.splice(index, 1);
  const previewElement = document.getElementById(previewId);
  if (previewElement) renderPreviews(previewElement);
};

/* ==========================================================================
   FORM SUBMISSION & LEAD MANAGEMENT
   ========================================================================== */
function initForms() {
  const quoteForms = document.querySelectorAll('.js-quote-form');

  quoteForms.forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();

      const name = form.querySelector('[name="name"]')?.value.trim();
      const phone = form.querySelector('[name="phone"]')?.value.trim();
      const service = form.querySelector('[name="service"]')?.value;
      const location = form.querySelector('[name="location"]')?.value;
      const notes = form.querySelector('[name="notes"]')?.value?.trim() || '';
      const discoveryCheck = form.querySelector('[name="discovery"]');
      const discovery = discoveryCheck ? (discoveryCheck.type === 'checkbox' ? discoveryCheck.checked : discoveryCheck.value === 'yes') : false;

      if (!name || !phone) {
        showToast('Lütfen Ad Soyad ve Telefon Numaranızı eksiksiz giriniz.', 'error');
        return;
      }

      // Telefon numarası doğrulaması (en az 10 rakam)
      const digitsOnly = phone.replace(/\D/g, '');
      if (digitsOnly.length < 10) {
        showToast('Lütfen geçerli bir telefon numarası giriniz (en az 10 hane).', 'error');
        return;
      }

      try {
        // Yeni Teklif Nesnesi
        const newLead = {
          id: 'CY-' + Date.now().toString().slice(-6),
          name: name,
          phone: phone,
          service: service || 'Genel Keşif / Danışmanlık',
          location: location || 'Antalya / Belirtilmedi',
          notes: notes || '-',
          isDiscovery: Boolean(discovery),
          files: [...selectedFilesStore],
          date: new Date().toLocaleString('tr-TR'),
          status: 'Yeni'
        };

        // localStorage kaydı (Can Yapı Yönetim Paneli için)
        saveLeadToStorage(newLead);

        // Ölçümleme (Analytics Event)
        if (window.CanYapiAnalytics) {
          window.CanYapiAnalytics.track('quote_form_submit', {
            service: newLead.service,
            location: newLead.location,
            isDiscovery: newLead.isDiscovery
          });
        }

        // Başarılı Mesajı
        showToast('Talebiniz başarıyla alındı! Ekibimiz en kısa sürede sizinle iletişime geçecektir.', 'success');
        form.reset();
        selectedFilesStore = [];
        const preview = form.querySelector('.file-preview-list');
        if (preview) preview.innerHTML = '';

        closeQuoteModal();

        // WhatsApp ile hızlı bildirim opsiyonu (Kullanıcı dilerse direkt WhatsApp'a da yollar)
        setTimeout(() => {
          askSendToWhatsApp(newLead);
        }, 700);
      } catch (err) {
        console.error('Form gönderim hatası:', err);
        showToast('Talebiniz kaydedilirken bir hata oluştu. Lütfen doğrudan bizi arayın.', 'error');
      }
    });
  });
}

function saveLeadToStorage(lead) {
  try {
    const existing = JSON.parse(localStorage.getItem('canyapi_leads') || '[]');
    existing.unshift(lead);
    localStorage.setItem('canyapi_leads', JSON.stringify(existing));
  } catch (err) {
    console.error('Lead storage error:', err);
  }
}

function askSendToWhatsApp(lead) {
  const text = encodeURIComponent(
    `*Yeni Proje Talebi (Can Yapı)*\n` +
    `👤 *Ad Soyad:* ${lead.name}\n` +
    `📞 *Telefon:* ${lead.phone}\n` +
    `🛠 *Hizmet:* ${lead.service}\n` +
    `📍 *Konum:* ${lead.location}\n` +
    `🔍 *Ücretsiz Keşif:* ${lead.isDiscovery ? 'Evet, Keşif Talep Edildi' : 'Hayır'}\n` +
    `📝 *Açıklama:* ${lead.notes}`
  );
  const waUrl = `https://wa.me/${CAN_YAPI_CONFIG.whatsapp}?text=${text}`;

  // Kullanıcıya WhatsApp ile de iletme önerisi
  if (confirm("Talebinizi WhatsApp üzerinden Can Yapı Antalya yetkilisine doğrudan iletmek ister misiniz?")) {
    window.open(waUrl, '_blank');
  }
}

/* ==========================================================================
   TOAST NOTIFICATION COMPONENT
   ========================================================================== */
function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  const icon = type === 'success' ? '✅' : type === 'error' ? '⚠️' : 'ℹ️';
  toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}
window.showToast = showToast;

/* ==========================================================================
   ANIMATED STATS COUNTERS (RK Reno Style)
   ========================================================================== */
function initCounters() {
  const counters = document.querySelectorAll('.js-counter');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const counter = entry.target;
        const target = parseInt(counter.getAttribute('data-target'), 10);
        let count = 0;
        const speed = target / 40;

        const updateCount = () => {
          count += speed;
          if (count < target) {
            counter.innerText = Math.ceil(count);
            requestAnimationFrame(updateCount);
          } else {
            counter.innerText = target;
          }
        };
        updateCount();
        observer.unobserve(counter);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
}

/* ==========================================================================
   IMAGE GALLERY LIGHTBOX (Modal Zoom)
   ========================================================================== */
function initGalleryLightbox() {
  const galleryItems = document.querySelectorAll('.gallery-item');
  if (!galleryItems.length) return;

  let lightbox = document.querySelector('.image-lightbox');
  if (!lightbox) {
    lightbox = document.createElement('div');
    lightbox.className = 'image-lightbox';
    lightbox.innerHTML = `
      <div class="lightbox-content">
        <button class="lightbox-close" aria-label="Kapat">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
        <img class="lightbox-img" src="" alt="Büyük Görsel">
        <div class="lightbox-caption"></div>
      </div>
    `;
    document.body.appendChild(lightbox);

    const closeBtn = lightbox.querySelector('.lightbox-close');
    const closeLightbox = () => {
      lightbox.classList.remove('active');
      document.body.style.overflow = '';
    };

    closeBtn.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) closeLightbox();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && lightbox.classList.contains('active')) {
        closeLightbox();
      }
    });
  }

  const lightboxImg = lightbox.querySelector('.lightbox-img');
  const lightboxCaption = lightbox.querySelector('.lightbox-caption');

  galleryItems.forEach(item => {
    item.addEventListener('click', () => {
      const img = item.querySelector('img');
      const caption = item.querySelector('.gallery-caption');
      if (img) {
        lightboxImg.src = img.src;
        lightboxImg.alt = img.alt || 'Can Yapı Uygulama';
        lightboxCaption.textContent = caption ? caption.textContent : 'Can Yapı Antalya';
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });
}

/* ==========================================================================
   DYNAMIC CMS CONTENT SYNC (Projects, Blog Nav, Site Texts)
   ========================================================================== */
async function initDynamicCmsContent() {
  // Blog bağlantısını menülere dinamik olarak ekle (yoksa)
  const navMenus = document.querySelectorAll('.nav-menu, .mobile-nav-list');
  navMenus.forEach(menu => {
    if (!menu.querySelector('a[href="blog.html"]')) {
      const projLink = menu.querySelector('a[href="projeler.html"]');
      const blogLink = document.createElement('a');
      blogLink.href = 'blog.html';
      blogLink.className = menu.classList.contains('mobile-nav-list') ? 'mobile-nav-link' : 'nav-link';
      blogLink.textContent = menu.classList.contains('mobile-nav-list') ? 'Blog & Rehber' : 'Blog';
      
      const currentPath = window.location.pathname;
      if (currentPath.includes('blog.html') || currentPath.includes('blog-detay.html')) {
        blogLink.classList.add('active');
      }

      if (projLink && projLink.nextSibling) {
        menu.insertBefore(blogLink, projLink.nextSibling);
      } else {
        menu.appendChild(blogLink);
      }
    }
  });

  if (!window.CmsClient) return;

  // 1. Projeler Sayfasında VE Ana Sayfada Çoklu Görsel Slider & Dinamik Listeleme
  const projectsGrid = document.querySelector('.projects-grid');
  if (projectsGrid) {
    try {
      const projects = await window.CmsClient.getProjects();
      if (projects && projects.length > 0) {
        const isProjelerPage = window.location.pathname.includes('projeler');
        // Ana sayfada en güncel 3 projeyi, projeler sayfasında tümünü listele
        const displayProjects = isProjelerPage ? projects : projects.slice(0, 3);

        projectsGrid.innerHTML = displayProjects.map((p, pIdx) => {
          const specsHtml = (p.specs || []).map(s => `
            <div class="spec-row">
              <span class="spec-label">${s.label}</span>
              <span class="spec-val ${s.isPassed ? 'badge-passed' : ''}">${s.val}</span>
            </div>
          `).join('');

          let imagesList = [];
          if (p.image) {
            imagesList.push(p.image);
          }
          if (Array.isArray(p.images)) {
            p.images.forEach(img => {
              if (img && !imagesList.includes(img)) {
                imagesList.push(img);
              }
            });
          }
          if (imagesList.length === 0) {
            imagesList = ['images/real/proje-luks-mutfak.webp'];
          }
          const hasMultiple = imagesList.length > 1;

          let thumbHtml = '';
          if (hasMultiple) {
            const slidesHtml = imagesList.map((imgUrl, idx) => `
              <div class="project-slider-slide gallery-item" data-index="${idx}">
                <img src="${imgUrl}" alt="${p.title} - Görsel ${idx+1}" loading="lazy" decoding="async" onerror="this.src='images/real/proje-luks-mutfak.webp'">
              </div>
            `).join('');

            const dotsHtml = imagesList.map((_, idx) => `
              <span class="project-slider-dot ${idx === 0 ? 'active' : ''}" data-target="${idx}"></span>
            `).join('');

            thumbHtml = `
              <div class="project-slider" id="slider-${p.id || pIdx}">
                <div class="project-slider-badge">📷 <span class="slider-counter">1/${imagesList.length}</span></div>
                <button type="button" class="project-slider-btn prev" aria-label="Önceki Görsel">‹</button>
                <div class="project-slider-track">
                  ${slidesHtml}
                </div>
                <button type="button" class="project-slider-btn next" aria-label="Sonraki Görsel">›</button>
                <div class="project-slider-dots">
                  ${dotsHtml}
                </div>
              </div>
            `;
          } else {
            thumbHtml = `
              <div class="project-thumb gallery-item">
                <img src="${imagesList[0]}" alt="${p.title}" loading="lazy" decoding="async" onerror="this.src='images/real/proje-luks-mutfak.webp'">
              </div>
            `;
          }

          return `
            <div class="project-card">
              ${thumbHtml}
              <div class="project-spec-table">
                <div class="spec-header">
                  <h4>${p.title}</h4>
                  <span class="spec-location">${p.location || 'Antalya'}</span>
                </div>
                ${specsHtml}
              </div>
            </div>
          `;
        }).join('');

        initProjectSliders();
        initGalleryLightbox();
      }
    } catch (err) {
      console.warn('Dinamik proje listeleme hatası:', err);
    }
  }

  // 2. Hizmetler Sayfasında ve Hizmet Sayfalarında Dinamik Galeri / Liste Senkronizasyonu
  try {
    const isServicesPage = window.location.pathname.includes('hizmetler');
    const servicesGrid = isServicesPage ? document.querySelector('.services-section .services-grid') : null;
    const serviceGalleryGrid = document.querySelector('.service-gallery-section .gallery-grid, .service-gallery-grid');

    if (servicesGrid || serviceGalleryGrid) {
      const services = await window.CmsClient.getServices();

      // Hizmetler Sayfasında Kartları Senkronize Et
      if (servicesGrid && Array.isArray(services) && services.length > 0) {
        servicesGrid.innerHTML = services.map(s => {
          const detailUrl = (s.slug || ('hizmet-' + s.id)).replace(/\.html$/, '');
          return `
            <div class="service-card">
              <div class="service-thumb">
                <img src="${s.image || 'images/logo.webp'}" alt="${s.title}" loading="lazy" decoding="async" onerror="this.src='images/logo.webp'">
              </div>
              <div class="service-content">
                <h3 class="service-title">${s.title}</h3>
                <p class="service-desc">${s.shortDesc || ''}</p>
                <div class="service-actions">
                  <a href="${detailUrl}" class="btn btn-outline-orange">Detay</a>
                  <button class="btn btn-primary js-open-quote-modal" data-service="${s.title}">Teklif Al</button>
                </div>
              </div>
            </div>
          `;
        }).join('');
      }

      // Hizmet Detay Sayfasında Alt Grid Galeri Senkronizasyonu
      if (serviceGalleryGrid && Array.isArray(services)) {
        const currentPath = window.location.pathname.toLowerCase();
        const matchedService = services.find(s => {
          if (!s.slug) return false;
          const cleanSlug = s.slug.replace('.html', '').toLowerCase();
          return currentPath.includes(cleanSlug);
        });

        if (matchedService && Array.isArray(matchedService.gallery) && matchedService.gallery.length > 0) {
          serviceGalleryGrid.innerHTML = matchedService.gallery.map((imgUrl, i) => `
            <div class="gallery-item">
              <img src="${imgUrl}" alt="${matchedService.title} Uygulaması ${i+1}" loading="lazy" decoding="async" onerror="this.src='images/logo.webp'">
              <div class="gallery-overlay">
                <span class="gallery-badge">Antalya Projesi</span>
                <h4 class="gallery-caption">${matchedService.title} Uygulaması #${i+1}</h4>
              </div>
              <div class="gallery-zoom-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          `).join('');

          initGalleryLightbox();
        }
      }
    }
  } catch (e) {
    console.warn('Hizmetler senkronizasyon hatası:', e);
  }

  // 3. Genel Site Metinleri (Hakkımızda, Hero, Telefon, Sosyal Medya vb.) Senkronizasyonu
  try {
    const settings = await window.CmsClient.getSettings();
    if (settings) {
      // Telefon
      if (settings.phone) {
        document.querySelectorAll('.top-phone span, .contact-phone-display, .top-bar-item strong').forEach(el => el.textContent = settings.phone);
        const cleanTel = settings.phone.replace(/[^0-9+]/g, '');
        document.querySelectorAll('a[href^="tel:"]').forEach(el => el.href = 'tel:' + cleanTel);
      }

      // WhatsApp
      if (settings.whatsapp) {
        const cleanWa = settings.whatsapp.replace(/[^0-9]/g, '');
        document.querySelectorAll('a[href*="wa.me"]').forEach(el => {
          el.href = `https://wa.me/${cleanWa}?text=Merhaba,%20Can%20Yapı%20Antalya%20için%20ücretsiz%20keşif%20ve%20fiyat%20teklifi%20almak%20istiyorum.`;
        });
      }

      // E-Posta
      if (settings.email) {
        document.querySelectorAll('a[href^="mailto:"]').forEach(el => el.href = 'mailto:' + settings.email);
        document.querySelectorAll('.contact-email-display').forEach(el => el.textContent = settings.email);
      }

      // Adres
      if (settings.address) {
        document.querySelectorAll('.contact-address-display, .top-bar-item span:not(.experience-badge)').forEach(el => {
          if (!el.textContent.includes('+90') && !el.textContent.includes('Yıl')) {
            el.textContent = settings.address;
          }
        });
      }

      // Deneyim Yılı
      if (settings.experienceYears) {
        document.querySelectorAll('.js-experience-years, .experience-badge').forEach(el => {
          el.textContent = settings.experienceYears;
        });
      }

      // Hero Başlık & Alt Açıklama (Ana Sayfa)
      if (settings.heroTitle) {
        const heroTitle = document.querySelector('.hero-title-main');
        if (heroTitle) heroTitle.innerHTML = settings.heroTitle;
      }
      if (settings.heroSubtitle) {
        const heroSub = document.querySelector('.hero-desc-main, .hero-poster-desc');
        if (heroSub) heroSub.textContent = settings.heroSubtitle;
      }

      // Hakkımızda Sayfası Dinamik İçerik Enjeksiyonu
      if (settings.aboutTitle) {
        const el = document.querySelector('.js-about-hero-title');
        if (el) el.innerHTML = settings.aboutTitle;
      }
      if (settings.aboutExcerpt) {
        const el = document.querySelector('.js-about-hero-desc');
        if (el) el.textContent = settings.aboutExcerpt;
      }
      if (settings.aboutStoryTitle) {
        const el = document.querySelector('.js-about-story-title');
        if (el) el.textContent = settings.aboutStoryTitle;
      }
      if (settings.aboutStory) {
        const el = document.querySelector('.js-about-story-body');
        if (el) {
          const paras = settings.aboutStory.split('\n\n').filter(Boolean);
          el.innerHTML = paras.map((p, idx) => `
            <p style="color: var(--text-muted); font-size: 1.02rem; line-height: 1.8; margin-bottom: ${idx === paras.length - 1 ? '24px' : '18px'};">
              ${p.replace(/\n/g, '<br>')}
            </p>
          `).join('');
        }
      }
      if (settings.aboutPhilosophyTitle) {
        const el = document.querySelector('.js-about-philosophy-title');
        if (el) el.textContent = settings.aboutPhilosophyTitle;
      }
      if (settings.aboutPhilosophy) {
        const el = document.querySelector('.js-about-philosophy-body');
        if (el) {
          const paras = settings.aboutPhilosophy.split('\n\n').filter(Boolean);
          el.innerHTML = paras.map((p, idx) => `
            <p style="color: ${idx === 0 ? 'var(--text-white)' : 'var(--text-muted)'}; font-size: ${idx === 0 ? '1.08rem' : '1.02rem'}; line-height: 1.85; margin-bottom: ${idx === paras.length - 1 ? '0' : '18px'};">
              ${p.replace(/\n/g, '<br>')}
            </p>
          `).join('');
        }
      }

      // Sosyal Medya İkonları
      const socialLinks = [
        { key: 'instagram', prefix: 'https://instagram.com/' },
        { key: 'facebook', prefix: 'https://facebook.com/' },
        { key: 'tiktok', prefix: 'https://tiktok.com/@' },
        { key: 'twitter', prefix: 'https://x.com/' }
      ];
      socialLinks.forEach(item => {
        const val = settings[item.key] || (settings.social && settings.social[item.key]);
        document.querySelectorAll(`.footer-social a[href*="${item.key}"], .social-links a[href*="${item.key}"]`).forEach(linkEl => {
          if (val && val.trim()) {
            linkEl.style.display = 'inline-flex';
            linkEl.href = val.startsWith('http') ? val : (item.prefix + val.replace('@', ''));
          } else {
            linkEl.style.display = 'none';
          }
        });
      });
    }
  } catch (e) {
    console.warn('Settings sync error:', e);
  }
}

/* ==========================================================================
   PROJECT SLIDER CONTROLS (Swipe & Navigation)
   ========================================================================== */
function initProjectSliders() {
  document.querySelectorAll('.project-slider').forEach(slider => {
    const track = slider.querySelector('.project-slider-track');
    const slides = slider.querySelectorAll('.project-slider-slide');
    const prevBtn = slider.querySelector('.project-slider-btn.prev');
    const nextBtn = slider.querySelector('.project-slider-btn.next');
    const dots = slider.querySelectorAll('.project-slider-dot');
    const counter = slider.querySelector('.slider-counter');
    if (!track || !slides.length) return;

    const total = slides.length;
    let currentIndex = 0;

    const updateSliderUI = (index) => {
      currentIndex = index;
      dots.forEach((dot, i) => dot.classList.toggle('active', i === index));
      if (counter) counter.innerText = `${index + 1}/${total}`;
    };

    if (prevBtn) {
      prevBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const newIndex = (currentIndex - 1 + total) % total;
        track.scrollTo({ left: newIndex * track.clientWidth, behavior: 'smooth' });
        updateSliderUI(newIndex);
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const newIndex = (currentIndex + 1) % total;
        track.scrollTo({ left: newIndex * track.clientWidth, behavior: 'smooth' });
        updateSliderUI(newIndex);
      });
    }

    dots.forEach((dot, idx) => {
      dot.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        track.scrollTo({ left: idx * track.clientWidth, behavior: 'smooth' });
        updateSliderUI(idx);
      });
    });

    track.addEventListener('scroll', () => {
      const scrollPos = track.scrollLeft;
      const width = track.clientWidth || 1;
      const index = Math.round(scrollPos / width);
      if (index !== currentIndex && index >= 0 && index < total) {
        updateSliderUI(index);
      }
    }, { passive: true });
  });
}
