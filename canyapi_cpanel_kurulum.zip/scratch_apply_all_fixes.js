const fs = require('fs');

const norm = s => s.replace(/\r\n/g, '\n');

// 1. UPDATE js/main.js
let mainJs = norm(fs.readFileSync('js/main.js', 'utf8'));

const oldImagesList = `          const imagesList = (Array.isArray(p.images) && p.images.length > 0) ? p.images : [p.image || 'images/real/proje-luks-mutfak.webp'];`;

const newImagesList = `          let imagesList = [];
          if (p.image) {
            imagesList.push(p.image);
          }
          if (Array.isArray(p.images)) {
            p.images.forEach(img => {
              if (img && !imagesList.includes(img)) {
                imagesList.push(img);
              }
            });
          }
          if (imagesList.length === 0) {
            imagesList = ['images/real/proje-luks-mutfak.webp'];
          }`;

if (!mainJs.includes(oldImagesList)) {
  console.error('Target imagesList not found in js/main.js!');
  process.exit(1);
}

mainJs = mainJs.replace(oldImagesList, newImagesList);
fs.writeFileSync('js/main.js', mainJs, 'utf8');
console.log('js/main.js updated: Cover image prioritized');

// 2. UPDATE js/admin.js
let adminJs = norm(fs.readFileSync('js/admin.js', 'utf8'));

const oldAdminImages = `      const mainCover = document.getElementById('projImage').value.trim();
      const images = currentModalProjectImages.length > 0 ? currentModalProjectImages : (mainCover ? [mainCover] : []);`;

const newAdminImages = `      const mainCover = document.getElementById('projImage').value.trim();
      let images = Array.isArray(currentModalProjectImages) ? [...currentModalProjectImages] : [];
      if (mainCover && !images.includes(mainCover)) {
        images.unshift(mainCover);
      }
      if (images.length === 0 && mainCover) {
        images = [mainCover];
      }`;

if (adminJs.includes(oldAdminImages)) {
  adminJs = adminJs.replace(oldAdminImages, newAdminImages);
  fs.writeFileSync('js/admin.js', adminJs, 'utf8');
  console.log('js/admin.js updated: Cover image saved at head of images array');
}

// 3. UPDATE all HTML files with version query string (?v=20261021c)
const htmlFiles = fs.readdirSync('.').filter(f => f.endsWith('.html'));
htmlFiles.forEach(f => {
  let content = norm(fs.readFileSync(f, 'utf8'));
  let changed = false;

  // Replace main.min.js
  if (content.includes('js/main.min.js')) {
    content = content.replace(/js\/main\.min\.js(\?v=[a-zA-Z0-9_-]+)?/g, 'js/main.min.js?v=20261021c');
    changed = true;
  }
  // Replace admin.min.js
  if (content.includes('js/admin.min.js')) {
    content = content.replace(/js\/admin\.min\.js(\?v=[a-zA-Z0-9_-]+)?/g, 'js/admin.min.js?v=20261021c');
    changed = true;
  }
  // Replace style.min.css
  if (content.includes('css/style.min.css')) {
    content = content.replace(/css\/style\.min\.css(\?v=[a-zA-Z0-9_-]+)?/g, 'css/style.min.css?v=20261021c');
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(f, content, 'utf8');
    console.log(`Updated cache-buster in ${f}`);
  }
});

// 4. UPDATE .htaccess to ensure sensible caching on JS/CSS
let htaccess = norm(fs.readFileSync('.htaccess', 'utf8'));
if (htaccess.includes('ExpiresByType application/javascript "access plus 1 month"')) {
  htaccess = htaccess.replace('ExpiresByType application/javascript "access plus 1 month"', 'ExpiresByType application/javascript "access plus 1 day"');
  htaccess = htaccess.replace('ExpiresByType text/javascript "access plus 1 month"', 'ExpiresByType text/javascript "access plus 1 day"');
  htaccess = htaccess.replace('ExpiresByType text/css "access plus 1 month"', 'ExpiresByType text/css "access plus 1 day"');
  fs.writeFileSync('.htaccess', htaccess, 'utf8');
  console.log('Updated .htaccess cache expires to 1 day for instant updates');
}
