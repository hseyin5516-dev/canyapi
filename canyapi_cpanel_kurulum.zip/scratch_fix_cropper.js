const fs = require('fs');

// 1. UPDATE admin.html
let html = fs.readFileSync('admin.html', 'utf8');

const targetCoverGroup = `<div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label">Ana Kapak Görseli * (Vitrin Fotoğrafı)</label>
          <div style="display: flex; gap: 8px;">
            <input type="text" id="projImage" class="form-control" placeholder="images/real/proje-luks-mutfak.jpg" required>
            <label class="btn btn-sm btn-outline-orange" style="margin: 0; display: flex; align-items: center; cursor: pointer; white-space: nowrap;">
              <span>Kapak Seç</span>
              <input type="file" id="projImageFile" accept="image/*" style="display: none;" aria-label="Fotoğraf veya dosya seçin">
            </label>
            <button type="button" id="btnOpenCropper" class="btn btn-sm btn-outline" style="white-space: nowrap; font-size: 0.8rem; display: flex; align-items: center; gap: 4px;" title="Görseli Yakınlaştır & Çerçevele">
              <span>✂️ Çerçevele</span>
            </button>
          </div>
          <small class="text-muted" style="display: block; margin-top: 4px;">💡 Dikey fotoğraflarda istediğiniz alanı (tavan, tezgah vb.) Instagram gibi kaydırıp odaklayabilirsiniz.</small>
        </div>`;

const newCoverGroup = `<div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label">Ana Kapak Görseli * (Vitrin Fotoğrafı)</label>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <input type="text" id="projImage" class="form-control" style="flex: 1; min-width: 220px;" placeholder="images/real/proje-luks-mutfak.jpg" required>
            <label class="btn btn-sm btn-outline-orange" style="margin: 0; display: inline-flex; align-items: center; gap: 4px; cursor: pointer; white-space: nowrap;">
              <span>📁 Fotoğraf Seç</span>
              <input type="file" id="projImageFile" accept="image/*" style="display: none;" aria-label="Fotoğraf veya dosya seçin">
            </label>
            <button type="button" id="btnOpenCropper" class="btn btn-sm btn-primary" style="white-space: nowrap; font-size: 0.82rem; display: inline-flex; align-items: center; gap: 4px;" title="Görseli Yakınlaştır & Çerçevele">
              <span>✂️ Fotoğrafı Çerçevele</span>
            </button>
          </div>
          <small class="text-muted" style="display: block; margin-top: 4px;">💡 Telefonla dikey çekilen fotoğraflarda istediğiniz alanı (tavan, tezgah vb.) parmağınızla kaydırıp odaklayabilirsiniz.</small>
        </div>`;

const targetControls = `<!-- Yakınlaştırma Kontrolleri -->
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 16px; margin: 18px 0; background: #0B0E13; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--admin-border);">
        <div style="display: flex; align-items: center; gap: 10px; flex: 1;">
          <span style="font-size: 0.82rem; color: #94A3B8; white-space: nowrap;">🔍 Yakınlaştır:</span>
          <button type="button" id="cropperZoomOut" class="btn btn-sm btn-outline" style="padding: 4px 10px;">−</button>
          <input type="range" id="cropperZoomSlider" min="1" max="3" step="0.02" value="1" style="flex: 1; accent-color: var(--primary-orange, #FF5500); cursor: pointer;">
          <button type="button" id="cropperZoomIn" class="btn btn-sm btn-outline" style="padding: 4px 10px;">+</button>
        </div>
        <button type="button" id="cropperResetBtn" class="btn btn-sm btn-outline" style="white-space: nowrap; font-size: 0.78rem;">
          ↺ Sıfırla
        </button>
      </div>`;

const newControls = `<!-- Hızlı Odaklama & Yakınlaştırma Kontrolleri -->
      <div style="display: flex; flex-direction: column; gap: 12px; margin: 18px 0; background: #0B0E13; padding: 14px 16px; border-radius: 8px; border: 1px solid var(--admin-border);">
        <!-- Hızlı Odaklama Butonları (Tavan / Orta / Zemin) -->
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;">
          <span style="font-size: 0.82rem; color: #94A3B8; font-weight: 600;">⚡ Hızlı Odak:</span>
          <div style="display: flex; gap: 6px;">
            <button type="button" id="cropAlignTop" class="btn btn-sm btn-outline" style="font-size: 0.78rem; padding: 4px 10px;">🔼 Üst / Tavan</button>
            <button type="button" id="cropAlignCenter" class="btn btn-sm btn-outline" style="font-size: 0.78rem; padding: 4px 10px;">⏺️ Merkez</button>
            <button type="button" id="cropAlignBottom" class="btn btn-sm btn-outline" style="font-size: 0.78rem; padding: 4px 10px;">🔽 Alt / Zemin</button>
          </div>
        </div>

        <!-- Yakınlaştırma Slider'ı -->
        <div style="display: flex; align-items: center; gap: 10px; width: 100%;">
          <span style="font-size: 0.82rem; color: #94A3B8; white-space: nowrap;">🔍 Yakınlaştır:</span>
          <button type="button" id="cropperZoomOut" class="btn btn-sm btn-outline" style="padding: 2px 8px;">−</button>
          <input type="range" id="cropperZoomSlider" min="0.5" max="3" step="0.01" value="1" style="flex: 1; accent-color: var(--primary-orange, #FF5500); cursor: pointer;">
          <button type="button" id="cropperZoomIn" class="btn btn-sm btn-outline" style="padding: 2px 8px;">+</button>
          <button type="button" id="cropperResetBtn" class="btn btn-sm btn-outline" style="white-space: nowrap; font-size: 0.75rem; padding: 4px 8px;">↺ Sıfırla</button>
        </div>
      </div>`;

const norm = s => s.replace(/\r\n/g, '\n');
let normHtml = norm(html);

if (normHtml.includes(norm(targetCoverGroup))) {
  normHtml = normHtml.replace(norm(targetCoverGroup), norm(newCoverGroup));
}
if (normHtml.includes(norm(targetControls))) {
  normHtml = normHtml.replace(norm(targetControls), norm(newControls));
}

fs.writeFileSync('admin.html', normHtml, 'utf8');
console.log('Updated admin.html successfully');

// 2. UPDATE js/admin.js
let adminJs = fs.readFileSync('js/admin.js', 'utf8');
let normJs = norm(adminJs);

const oldUploadBlock = `  // Proje Tekil Görsel Yükleme & Otomatik Çerçeveleyici Açma
  const projFileInput = document.getElementById('projImageFile');
  if (projFileInput) {
    projFileInput.addEventListener('change', async function() {
      if (this.files && this.files[0]) {
        window.showToast?.('Fotoğraf yükleniyor...', 'info');
        const res = await window.CmsClient.uploadPhoto(this.files[0]);
        if (res.success && res.url) {
          document.getElementById('projImage').value = res.url;
          if (!currentModalProjectImages.includes(res.url)) {
            currentModalProjectImages.unshift(res.url);
            renderModalProjectImages();
          }
          window.showToast?.('Fotoğraf yüklendi! Şimdi çerçeveyi ayarlayabilirsiniz.', 'success');
          setTimeout(() => {
            openImageCropperModal(res.url);
          }, 350);
        }
      }
    });
  }

  // Çerçeveleyiciyi Manuel Açma Butonu
  const btnOpenCropper = document.getElementById('btnOpenCropper');
  if (btnOpenCropper) {
    btnOpenCropper.addEventListener('click', function() {
      const currentUrl = document.getElementById('projImage')?.value.trim();
      if (!currentUrl) {
        window.showToast?.('Lütfen önce bir fotoğraf seçin veya geçerli bir URL girin.', 'error');
        return;
      }
      openImageCropperModal(currentUrl);
    });
  }`;

const newUploadBlock = `  // Proje Tekil Görsel Yükleme (Anında Önizleme & Çerçeveleyici)
  const projFileInput = document.getElementById('projImageFile');
  if (projFileInput) {
    projFileInput.addEventListener('change', function() {
      if (this.files && this.files[0]) {
        const file = this.files[0];
        const localBlobUrl = URL.createObjectURL(file);
        openImageCropperModal(localBlobUrl, null, file);
      }
    });
  }

  // Çerçeveleyici Butonu (Görsel yoksa dosya seçiciyi anında açar)
  const btnOpenCropper = document.getElementById('btnOpenCropper');
  if (btnOpenCropper) {
    btnOpenCropper.addEventListener('click', function() {
      const currentUrl = document.getElementById('projImage')?.value.trim();
      if (!currentUrl) {
        const fileInput = document.getElementById('projImageFile');
        if (fileInput) fileInput.click();
        return;
      }
      openImageCropperModal(currentUrl);
    });
  }`;

if (normJs.includes(norm(oldUploadBlock))) {
  normJs = normJs.replace(norm(oldUploadBlock), norm(newUploadBlock));
}

const cropperHeader = '/* ==========================================================================\n   INSTAGRAM TARZI İNTERAKTİF ÇERÇEVELEME & ODAKLAMA MOTORU (Pan & Zoom Cropper)';
const cropperIndex = normJs.indexOf(cropperHeader);
if (cropperIndex !== -1) {
  normJs = normJs.substring(0, cropperIndex);
}

const enhancedCropperEngine = `/* ==========================================================================
   INSTAGRAM TARZI İNTERAKTİF ÇERÇEVELEME & ODAKLAMA MOTORU (Pan & Zoom Cropper)
   ========================================================================== */
let cropperState = {
  img: null,
  viewport: null,
  slider: null,
  modal: null,
  scale: 1,
  minScale: 1,
  maxScale: 3.5,
  x: 0,
  y: 0,
  isDragging: false,
  startX: 0,
  startY: 0,
  startImgX: 0,
  startImgY: 0,
  naturalW: 0,
  naturalH: 0,
  originalUrl: '',
  pendingFile: null,
  pinchDistance: 0,
  onComplete: null
};

window.openImageCropperModal = function(imageUrl, onComplete, pendingFileObj) {
  const modal = document.getElementById('imageCropperModal');
  const img = document.getElementById('cropperSourceImg');
  const viewport = document.getElementById('cropperViewport');
  const slider = document.getElementById('cropperZoomSlider');

  if (!modal || !img || !viewport) return;

  cropperState.modal = modal;
  cropperState.img = img;
  cropperState.viewport = viewport;
  cropperState.slider = slider;
  cropperState.originalUrl = imageUrl;
  cropperState.pendingFile = pendingFileObj || null;
  cropperState.onComplete = onComplete;

  modal.classList.remove('hidden');

  img.onload = function() {
    cropperState.naturalW = img.naturalWidth || 800;
    cropperState.naturalH = img.naturalHeight || 600;

    const vw = viewport.clientWidth || 560;
    const vh = viewport.clientHeight || 315;

    const scaleX = vw / cropperState.naturalW;
    const scaleY = vh / cropperState.naturalH;
    cropperState.minScale = Math.max(scaleX, scaleY);
    cropperState.scale = cropperState.minScale;
    cropperState.maxScale = Math.max(cropperState.minScale * 3.5, 2.5);

    if (slider) {
      slider.min = (cropperState.minScale * 0.75).toFixed(4);
      slider.max = cropperState.maxScale.toFixed(4);
      slider.step = ((cropperState.maxScale - cropperState.minScale * 0.75) / 100).toFixed(4);
      slider.value = cropperState.scale.toFixed(4);
    }

    cropperState.x = (vw - cropperState.naturalW * cropperState.scale) / 2;
    cropperState.y = (vh - cropperState.naturalH * cropperState.scale) / 2;

    applyCropperTransform();
    initCropperEventsOnce();
  };

  img.onerror = function() {
    window.showToast?.('Görsel yüklenemedi. Lütfen geçerli bir görsel seçiniz.', 'error');
    closeImageCropperModal();
  };

  if (!imageUrl.startsWith('blob:') && !imageUrl.startsWith('data:')) {
    img.crossOrigin = 'anonymous';
  } else {
    img.removeAttribute('crossOrigin');
  }
  img.src = imageUrl;
};

window.closeImageCropperModal = function() {
  const modal = document.getElementById('imageCropperModal');
  if (modal) modal.classList.add('hidden');
};

function clampCropperBounds() {
  if (!cropperState.viewport || !cropperState.naturalW) return;
  const vw = cropperState.viewport.clientWidth;
  const vh = cropperState.viewport.clientHeight;
  const renderedW = cropperState.naturalW * cropperState.scale;
  const renderedH = cropperState.naturalH * cropperState.scale;

  if (renderedW <= vw) {
    cropperState.x = (vw - renderedW) / 2;
  } else {
    const minX = vw - renderedW;
    const maxX = 0;
    cropperState.x = Math.min(maxX, Math.max(minX, cropperState.x));
  }

  if (renderedH <= vh) {
    cropperState.y = (vh - renderedH) / 2;
  } else {
    const minY = vh - renderedH;
    const maxY = 0;
    cropperState.y = Math.min(maxY, Math.max(minY, cropperState.y));
  }
}

function applyCropperTransform() {
  clampCropperBounds();
  if (cropperState.img) {
    cropperState.img.style.transform = "translate(" + cropperState.x + "px, " + cropperState.y + "px) scale(" + cropperState.scale + ")";
  }
}

let cropperEventsInitialized = false;
function initCropperEventsOnce() {
  if (cropperEventsInitialized) return;
  cropperEventsInitialized = true;

  const viewport = document.getElementById('cropperViewport');
  const slider = document.getElementById('cropperZoomSlider');
  const zoomIn = document.getElementById('cropperZoomIn');
  const zoomOut = document.getElementById('cropperZoomOut');
  const resetBtn = document.getElementById('cropperResetBtn');
  const applyBtn = document.getElementById('cropperApplyBtn');

  const alignTop = document.getElementById('cropAlignTop');
  const alignCenter = document.getElementById('cropAlignCenter');
  const alignBottom = document.getElementById('cropAlignBottom');

  if (!viewport) return;

  if (alignTop) {
    alignTop.addEventListener('click', () => {
      cropperState.y = 0;
      applyCropperTransform();
    });
  }
  if (alignCenter) {
    alignCenter.addEventListener('click', () => {
      const vh = viewport.clientHeight;
      const renderedH = cropperState.naturalH * cropperState.scale;
      cropperState.y = (vh - renderedH) / 2;
      applyCropperTransform();
    });
  }
  if (alignBottom) {
    alignBottom.addEventListener('click', () => {
      const vh = viewport.clientHeight;
      const renderedH = cropperState.naturalH * cropperState.scale;
      cropperState.y = vh - renderedH;
      applyCropperTransform();
    });
  }

  viewport.addEventListener('mousedown', function(e) {
    e.preventDefault();
    cropperState.isDragging = true;
    cropperState.startX = e.clientX;
    cropperState.startY = e.clientY;
    cropperState.startImgX = cropperState.x;
    cropperState.startImgY = cropperState.y;
    viewport.style.cursor = 'grabbing';
  });

  window.addEventListener('mousemove', function(e) {
    if (!cropperState.isDragging) return;
    const dx = e.clientX - cropperState.startX;
    const dy = e.clientY - cropperState.startY;
    cropperState.x = cropperState.startImgX + dx;
    cropperState.y = cropperState.startImgY + dy;
    applyCropperTransform();
  });

  window.addEventListener('mouseup', function() {
    if (cropperState.isDragging) {
      cropperState.isDragging = false;
      viewport.style.cursor = 'grab';
    }
  });

  viewport.addEventListener('touchstart', function(e) {
    if (e.touches.length === 1) {
      cropperState.isDragging = true;
      cropperState.startX = e.touches[0].clientX;
      cropperState.startY = e.touches[0].clientY;
      cropperState.startImgX = cropperState.x;
      cropperState.startImgY = cropperState.y;
    } else if (e.touches.length === 2) {
      cropperState.isDragging = false;
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      cropperState.pinchDistance = Math.hypot(dx, dy);
    }
  }, { passive: false });

  viewport.addEventListener('touchmove', function(e) {
    if (e.touches.length === 1 && cropperState.isDragging) {
      if (e.cancelable) e.preventDefault();
      const dx = e.touches[0].clientX - cropperState.startX;
      const dy = e.touches[0].clientY - cropperState.startY;
      cropperState.x = cropperState.startImgX + dx;
      cropperState.y = cropperState.startImgY + dy;
      applyCropperTransform();
    } else if (e.touches.length === 2) {
      if (e.cancelable) e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      if (cropperState.pinchDistance > 0) {
        const factor = dist / cropperState.pinchDistance;
        setCropperZoom(cropperState.scale * factor);
      }
      cropperState.pinchDistance = dist;
    }
  }, { passive: false });

  viewport.addEventListener('touchend', function() {
    cropperState.isDragging = false;
    cropperState.pinchDistance = 0;
  });

  viewport.addEventListener('wheel', function(e) {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.08 : 0.92;
    setCropperZoom(cropperState.scale * factor);
  }, { passive: false });

  function setCropperZoom(newScale) {
    newScale = Math.min(cropperState.maxScale, Math.max(cropperState.minScale * 0.75, newScale));
    const vw = viewport.clientWidth;
    const vh = viewport.clientHeight;

    const centerViewportX = vw / 2;
    const centerViewportY = vh / 2;

    const imgCenterX = (centerViewportX - cropperState.x) / cropperState.scale;
    const imgCenterY = (centerViewportY - cropperState.y) / cropperState.scale;

    cropperState.scale = newScale;
    cropperState.x = centerViewportX - imgCenterX * cropperState.scale;
    cropperState.y = centerViewportY - imgCenterY * cropperState.scale;

    if (slider) slider.value = cropperState.scale.toFixed(4);
    applyCropperTransform();
  }

  if (slider) {
    slider.addEventListener('input', function() {
      setCropperZoom(parseFloat(this.value));
    });
  }

  if (zoomIn) zoomIn.addEventListener('click', () => setCropperZoom(cropperState.scale * 1.15));
  if (zoomOut) zoomOut.addEventListener('click', () => setCropperZoom(cropperState.scale * 0.85));

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      cropperState.scale = cropperState.minScale;
      const vw = viewport.clientWidth;
      const vh = viewport.clientHeight;
      cropperState.x = (vw - cropperState.naturalW * cropperState.scale) / 2;
      cropperState.y = (vh - cropperState.naturalH * cropperState.scale) / 2;
      if (slider) slider.value = cropperState.scale.toFixed(4);
      applyCropperTransform();
    });
  }

  if (applyBtn) {
    applyBtn.addEventListener('click', async function() {
      applyBtn.disabled = true;
      applyBtn.innerHTML = '<span>⏳ Kaydediliyor...</span>';

      try {
        const vw = viewport.clientWidth;
        const vh = viewport.clientHeight;
        const renderedW = cropperState.naturalW * cropperState.scale;
        const scaleRatio = cropperState.naturalW / renderedW;

        const srcX = Math.max(0, -cropperState.x * scaleRatio);
        const srcY = Math.max(0, -cropperState.y * scaleRatio);
        const srcW = Math.min(cropperState.naturalW - srcX, vw * scaleRatio);
        const srcH = Math.min(cropperState.naturalH - srcY, vh * scaleRatio);

        const canvas = document.createElement('canvas');
        canvas.width = 1280;
        canvas.height = 720;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(cropperState.img, srcX, srcY, srcW, srcH, 0, 0, 1280, 720);

        canvas.toBlob(async function(blob) {
          if (!blob) {
            window.showToast?.('Kırpma işlemi başarısız oldu.', 'error');
            applyBtn.disabled = false;
            applyBtn.innerHTML = '<span>✓ Çerçeveyi Kaydet & Uygula</span>';
            return;
          }

          const file = new File([blob], 'thumb_' + Date.now() + '.webp', { type: 'image/webp' });
          const res = await window.CmsClient.uploadPhoto(file);

          if (res && res.success && res.url) {
            const croppedUrl = res.url;
            const projInput = document.getElementById('projImage');
            if (projInput) projInput.value = croppedUrl;

            if (cropperState.pendingFile) {
              window.CmsClient.uploadPhoto(cropperState.pendingFile).then(origRes => {
                if (origRes && origRes.success && origRes.url) {
                  if (!currentModalProjectImages.includes(origRes.url)) {
                    currentModalProjectImages.unshift(origRes.url);
                    renderModalProjectImages();
                  }
                }
              });
            } else if (cropperState.originalUrl && !cropperState.originalUrl.startsWith('blob:')) {
              if (!currentModalProjectImages.includes(cropperState.originalUrl)) {
                currentModalProjectImages.unshift(cropperState.originalUrl);
                renderModalProjectImages();
              }
            }

            if (typeof cropperState.onComplete === 'function') {
              cropperState.onComplete(croppedUrl, cropperState.originalUrl);
            }

            window.showToast?.('Önizleme çerçevesi başarıyla uygulandı!', 'success');
            closeImageCropperModal();
          } else {
            window.showToast?.('Fotoğraf kaydedilemedi.', 'error');
          }

          applyBtn.disabled = false;
          applyBtn.innerHTML = '<span>✓ Çerçeveyi Kaydet & Uygula</span>';
        }, 'image/webp', 0.88);

      } catch (err) {
        console.error('Cropper error:', err);
        window.showToast?.('Hata: ' + err.message, 'error');
        applyBtn.disabled = false;
        applyBtn.innerHTML = '<span>✓ Çerçeveyi Kaydet & Uygula</span>';
      }
    });
  }
}
`;

normJs += enhancedCropperEngine;

fs.writeFileSync('js/admin.js', normJs, 'utf8');
console.log('Updated js/admin.js successfully');
