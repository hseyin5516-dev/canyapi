const fs = require('fs');

const norm = s => s.replace(/\r\n/g, '\n');

// 1. UPDATE admin.html
let html = norm(fs.readFileSync('admin.html', 'utf8'));

// Remove main.min.js from admin.html
html = html.replace('  <script defer src="js/main.min.js"></script>\n', '');

// Update btnOpenCropper to include onclick="handleOpenCropperClick()"
const oldBtn = `<button type="button" id="btnOpenCropper" class="btn btn-sm btn-primary" style="white-space: nowrap; font-size: 0.82rem; display: inline-flex; align-items: center; gap: 4px;" title="Görseli Yakınlaştır & Çerçevele">
              <span>✂️ Fotoğrafı Çerçevele</span>
            </button>`;

const newBtn = `<button type="button" id="btnOpenCropper" onclick="handleOpenCropperClick()" class="btn btn-sm btn-primary" style="white-space: nowrap; font-size: 0.82rem; display: inline-flex; align-items: center; gap: 4px;" title="Görseli Yakınlaştır & Çerçevele">
              <span>✂️ Fotoğrafı Çerçevele</span>
            </button>`;

if (html.includes(oldBtn)) {
  html = html.replace(oldBtn, newBtn);
}

// Add direct file picker & gallery strip into cropper modal
const oldCropperHeader = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0; font-size: 1.25rem; color: #FFF; display: flex; align-items: center; gap: 8px;">
          <span>📷</span> Fotoğrafı Çerçevele & Odakla
        </h3>
        <button type="button" onclick="closeImageCropperModal()" style="background: none; border: none; color: #94A3B8; font-size: 1.5rem; cursor: pointer;">✕</button>
      </div>`;

const newCropperHeader = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
        <h3 style="margin: 0; font-size: 1.25rem; color: #FFF; display: flex; align-items: center; gap: 8px;">
          <span>📷</span> Fotoğrafı Çerçevele & Odakla
        </h3>
        <div style="display: flex; align-items: center; gap: 8px;">
          <label class="btn btn-sm btn-outline-orange" style="margin: 0; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; font-size: 0.78rem;">
            <span>📁 Başka Fotoğraf Seç</span>
            <input type="file" id="cropperDirectFile" accept="image/*" style="display: none;" onchange="handleCropperDirectFile(this)">
          </label>
          <button type="button" onclick="closeImageCropperModal()" style="background: none; border: none; color: #94A3B8; font-size: 1.5rem; cursor: pointer; line-height: 1;">✕</button>
        </div>
      </div>`;

if (html.includes(oldCropperHeader)) {
  html = html.replace(oldCropperHeader, newCropperHeader);
}

const oldCropperFooterEnd = `<div style="display: flex; justify-content: flex-end; gap: 10px;">
        <button type="button" onclick="closeImageCropperModal()" class="btn btn-outline">İptal</button>
        <button type="button" id="cropperApplyBtn" class="btn btn-primary" style="display: flex; align-items: center; gap: 6px;">
          <span>✓ Çerçeveyi Kaydet & Uygula</span>
        </button>
      </div>
    </div>
  </div>`;

const newCropperFooterEnd = `<!-- Projedeki Diğer Fotoğraflardan Hızlı Seçim Şeridi -->
      <div id="cropperGalleryThumbnails" style="display: none; gap: 8px; overflow-x: auto; padding: 10px 0; align-items: center; border-top: 1px solid var(--admin-border); margin-bottom: 14px;"></div>

      <div style="display: flex; justify-content: flex-end; gap: 10px;">
        <button type="button" onclick="closeImageCropperModal()" class="btn btn-outline">İptal</button>
        <button type="button" id="cropperApplyBtn" class="btn btn-primary" style="display: flex; align-items: center; gap: 6px;">
          <span>✓ Çerçeveyi Kaydet & Uygula</span>
        </button>
      </div>
    </div>
  </div>`;

if (html.includes(oldCropperFooterEnd)) {
  html = html.replace(oldCropperFooterEnd, newCropperFooterEnd);
}

fs.writeFileSync('admin.html', html, 'utf8');
console.log('admin.html successfully updated');

// 2. UPDATE js/admin.js
let adminJs = norm(fs.readFileSync('js/admin.js', 'utf8'));

// Update renderModalProjectImages to make thumbnails clickable with ✂️
const oldRenderThumb = `  container.innerHTML = currentModalProjectImages.map((imgUrl, i) => \`
    <div style="position: relative; width: 64px; height: 64px; border-radius: 6px; overflow: hidden; border: 1px solid var(--admin-border); background: #000;">
      <img src="\${imgUrl}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='images/logo.png'">
      <button type="button" onclick="removeModalProjectImage(\${i})" style="position: absolute; top: 2px; right: 2px; background: rgba(255,0,0,0.85); color: white; border: none; width: 18px; height: 18px; border-radius: 50%; font-size: 11px; cursor: pointer; display: flex; align-items: center; justify-content: center; line-height: 1;" title="Fotoğrafı Kaldır">✕</button>
      <span style="position: absolute; bottom: 2px; left: 2px; background: rgba(0,0,0,0.7); color: #FFF; font-size: 9px; padding: 1px 3px; border-radius: 2px;">\${i+1}</span>
    </div>
  \`).join('');`;

const newRenderThumb = `  const currentCover = document.getElementById('projImage')?.value.trim();
  container.innerHTML = currentModalProjectImages.map((imgUrl, i) => {
    const isCover = currentCover === imgUrl;
    return \`
      <div onclick="selectAndCropProjectImage('\${imgUrl}')" style="cursor: pointer; position: relative; width: 68px; height: 68px; border-radius: 6px; overflow: hidden; border: 2px solid \${isCover ? 'var(--primary-orange, #FF5500)' : 'var(--admin-border)'}; background: #000;" title="Kapak Olarak Seç ve Çerçevele">
        <img src="\${normalizeImageUrl(imgUrl)}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='images/logo.webp'">
        <button type="button" onclick="event.stopPropagation(); removeModalProjectImage(\${i})" style="position: absolute; top: 2px; right: 2px; background: rgba(255,0,0,0.85); color: white; border: none; width: 18px; height: 18px; border-radius: 50%; font-size: 11px; cursor: pointer; display: flex; align-items: center; justify-content: center; line-height: 1;" title="Fotoğrafı Kaldır">✕</button>
        <span style="position: absolute; bottom: 2px; left: 2px; background: rgba(0,0,0,0.75); color: #FFF; font-size: 9px; padding: 1px 4px; border-radius: 2px; display: flex; align-items: center; gap: 2px;">
          \${i+1} ✂️
        </span>
      </div>
    \`;
  }).join('');`;

if (adminJs.includes(oldRenderThumb)) {
  adminJs = adminJs.replace(oldRenderThumb, newRenderThumb);
}

// Find cropper code and replace with bulletproof version
const cropperHeader = '/* ==========================================================================\n   INSTAGRAM TARZI İNTERAKTİF ÇERÇEVELEME & ODAKLAMA MOTORU (Pan & Zoom Cropper)';
const cropperIndex = adminJs.indexOf(cropperHeader);
if (cropperIndex !== -1) {
  adminJs = adminJs.substring(0, cropperIndex);
}

const bulletproofCropper = `/* ==========================================================================
   INSTAGRAM TARZI İNTERAKTİF ÇERÇEVELEME & ODAKLAMA MOTORU (Pan & Zoom Cropper)
   ========================================================================== */

function normalizeImageUrl(url) {
  if (!url) return '';
  url = url.trim();
  if (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('blob:') || url.startsWith('data:')) {
    return url;
  }
  return '/' + url.replace(/^\\/+/, '');
}
window.normalizeImageUrl = normalizeImageUrl;

window.selectAndCropProjectImage = function(imgUrl) {
  const projInput = document.getElementById('projImage');
  if (projInput) projInput.value = imgUrl;
  renderModalProjectImages();
  window.openImageCropperModal(imgUrl);
};

window.handleOpenCropperClick = function() {
  let currentUrl = document.getElementById('projImage')?.value.trim();
  if (!currentUrl && Array.isArray(currentModalProjectImages) && currentModalProjectImages.length > 0) {
    currentUrl = currentModalProjectImages[0];
    const projInput = document.getElementById('projImage');
    if (projInput) projInput.value = currentUrl;
  }
  if (!currentUrl) {
    const fileInput = document.getElementById('projImageFile');
    if (fileInput) fileInput.click();
    return;
  }
  window.openImageCropperModal(currentUrl);
};

window.handleCropperDirectFile = function(input) {
  if (input.files && input.files[0]) {
    const file = input.files[0];
    const localBlobUrl = URL.createObjectURL(file);
    window.openImageCropperModal(localBlobUrl, null, file);
  }
};

let cropperState = {
  img: null,
  viewport: null,
  slider: null,
  modal: null,
  scale: 1,
  minScale: 1,
  maxScale: 3.5,
  x: 0,
  y: 0,
  isDragging: false,
  startX: 0,
  startY: 0,
  startImgX: 0,
  startImgY: 0,
  naturalW: 0,
  naturalH: 0,
  originalUrl: '',
  pendingFile: null,
  pinchDistance: 0,
  onComplete: null
};

window.openImageCropperModal = function(imageUrl, onComplete, pendingFileObj) {
  const modal = document.getElementById('imageCropperModal');
  const img = document.getElementById('cropperSourceImg');
  const viewport = document.getElementById('cropperViewport');
  const slider = document.getElementById('cropperZoomSlider');

  if (!modal || !img || !viewport) {
    console.error('Cropper elements missing');
    return;
  }

  cropperState.modal = modal;
  cropperState.img = img;
  cropperState.viewport = viewport;
  cropperState.slider = slider;
  cropperState.originalUrl = imageUrl;
  cropperState.pendingFile = pendingFileObj || null;
  cropperState.onComplete = onComplete;

  modal.classList.remove('hidden');

  // Galeri fotoğraflarından hızlı seçim şeridi
  const cropperThumbStrip = document.getElementById('cropperGalleryThumbnails');
  if (cropperThumbStrip) {
    if (Array.isArray(currentModalProjectImages) && currentModalProjectImages.length > 0) {
      cropperThumbStrip.innerHTML = '<span style="font-size:0.75rem;color:#94A3B8;white-space:nowrap;margin-right:4px;">Proje Fotoğrafları:</span>' + currentModalProjectImages.map((u, idx) => \`
        <div onclick="window.openImageCropperModal('\${u}')" style="cursor:pointer;width:44px;height:44px;border-radius:4px;overflow:hidden;border:2px solid \${u === imageUrl ? 'var(--primary-orange, #FF5500)' : 'rgba(255,255,255,0.2)'};flex-shrink:0;" title="Fotoğraf \${idx+1}">
          <img src="\${normalizeImageUrl(u)}" style="width:100%;height:100%;object-fit:cover;">
        </div>
      \`).join('');
      cropperThumbStrip.style.display = 'flex';
    } else {
      cropperThumbStrip.style.display = 'none';
    }
  }

  function setupMetrics() {
    cropperState.naturalW = img.naturalWidth || 800;
    cropperState.naturalH = img.naturalHeight || 600;

    const vw = viewport.clientWidth || 560;
    const vh = viewport.clientHeight || 315;

    const scaleX = vw / cropperState.naturalW;
    const scaleY = vh / cropperState.naturalH;
    cropperState.minScale = Math.max(scaleX, scaleY);
    cropperState.scale = cropperState.minScale;
    cropperState.maxScale = Math.max(cropperState.minScale * 3.5, 2.5);

    if (slider) {
      slider.min = (cropperState.minScale * 0.75).toFixed(4);
      slider.max = cropperState.maxScale.toFixed(4);
      slider.step = ((cropperState.maxScale - cropperState.minScale * 0.75) / 100).toFixed(4);
      slider.value = cropperState.scale.toFixed(4);
    }

    cropperState.x = (vw - cropperState.naturalW * cropperState.scale) / 2;
    cropperState.y = (vh - cropperState.naturalH * cropperState.scale) / 2;

    applyCropperTransform();
    initCropperEventsOnce();
  }

  img.onload = setupMetrics;

  img.onerror = function() {
    console.warn('Görsel yüklenemedi:', imageUrl);
    window.showToast?.('Fotoğraf yüklenemedi. Lütfen "Başka Fotoğraf Seç" butonundan görsel seçin.', 'error');
  };

  img.removeAttribute('crossOrigin');

  const resolved = normalizeImageUrl(imageUrl);
  img.src = resolved;

  if (img.complete && img.naturalWidth > 0) {
    setupMetrics();
  }
};

window.closeImageCropperModal = function() {
  const modal = document.getElementById('imageCropperModal');
  if (modal) modal.classList.add('hidden');
};

function clampCropperBounds() {
  if (!cropperState.viewport || !cropperState.naturalW) return;
  const vw = cropperState.viewport.clientWidth;
  const vh = cropperState.viewport.clientHeight;
  const renderedW = cropperState.naturalW * cropperState.scale;
  const renderedH = cropperState.naturalH * cropperState.scale;

  if (renderedW <= vw) {
    cropperState.x = (vw - renderedW) / 2;
  } else {
    const minX = vw - renderedW;
    const maxX = 0;
    cropperState.x = Math.min(maxX, Math.max(minX, cropperState.x));
  }

  if (renderedH <= vh) {
    cropperState.y = (vh - renderedH) / 2;
  } else {
    const minY = vh - renderedH;
    const maxY = 0;
    cropperState.y = Math.min(maxY, Math.max(minY, cropperState.y));
  }
}

function applyCropperTransform() {
  clampCropperBounds();
  if (cropperState.img) {
    cropperState.img.style.transform = "translate(" + cropperState.x + "px, " + cropperState.y + "px) scale(" + cropperState.scale + ")";
  }
}

let cropperEventsInitialized = false;
function initCropperEventsOnce() {
  if (cropperEventsInitialized) return;
  cropperEventsInitialized = true;

  const viewport = document.getElementById('cropperViewport');
  const slider = document.getElementById('cropperZoomSlider');
  const zoomIn = document.getElementById('cropperZoomIn');
  const zoomOut = document.getElementById('cropperZoomOut');
  const resetBtn = document.getElementById('cropperResetBtn');
  const applyBtn = document.getElementById('cropperApplyBtn');

  const alignTop = document.getElementById('cropAlignTop');
  const alignCenter = document.getElementById('cropAlignCenter');
  const alignBottom = document.getElementById('cropAlignBottom');

  if (!viewport) return;

  if (alignTop) {
    alignTop.addEventListener('click', () => {
      cropperState.y = 0;
      applyCropperTransform();
    });
  }
  if (alignCenter) {
    alignCenter.addEventListener('click', () => {
      const vh = viewport.clientHeight;
      const renderedH = cropperState.naturalH * cropperState.scale;
      cropperState.y = (vh - renderedH) / 2;
      applyCropperTransform();
    });
  }
  if (alignBottom) {
    alignBottom.addEventListener('click', () => {
      const vh = viewport.clientHeight;
      const renderedH = cropperState.naturalH * cropperState.scale;
      cropperState.y = vh - renderedH;
      applyCropperTransform();
    });
  }

  viewport.addEventListener('mousedown', function(e) {
    e.preventDefault();
    cropperState.isDragging = true;
    cropperState.startX = e.clientX;
    cropperState.startY = e.clientY;
    cropperState.startImgX = cropperState.x;
    cropperState.startImgY = cropperState.y;
    viewport.style.cursor = 'grabbing';
  });

  window.addEventListener('mousemove', function(e) {
    if (!cropperState.isDragging) return;
    const dx = e.clientX - cropperState.startX;
    const dy = e.clientY - cropperState.startY;
    cropperState.x = cropperState.startImgX + dx;
    cropperState.y = cropperState.startImgY + dy;
    applyCropperTransform();
  });

  window.addEventListener('mouseup', function() {
    if (cropperState.isDragging) {
      cropperState.isDragging = false;
      viewport.style.cursor = 'grab';
    }
  });

  viewport.addEventListener('touchstart', function(e) {
    if (e.touches.length === 1) {
      cropperState.isDragging = true;
      cropperState.startX = e.touches[0].clientX;
      cropperState.startY = e.touches[0].clientY;
      cropperState.startImgX = cropperState.x;
      cropperState.startImgY = cropperState.y;
    } else if (e.touches.length === 2) {
      cropperState.isDragging = false;
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      cropperState.pinchDistance = Math.hypot(dx, dy);
    }
  }, { passive: false });

  viewport.addEventListener('touchmove', function(e) {
    if (e.touches.length === 1 && cropperState.isDragging) {
      if (e.cancelable) e.preventDefault();
      const dx = e.touches[0].clientX - cropperState.startX;
      const dy = e.touches[0].clientY - cropperState.startY;
      cropperState.x = cropperState.startImgX + dx;
      cropperState.y = cropperState.startImgY + dy;
      applyCropperTransform();
    } else if (e.touches.length === 2) {
      if (e.cancelable) e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      if (cropperState.pinchDistance > 0) {
        const factor = dist / cropperState.pinchDistance;
        setCropperZoom(cropperState.scale * factor);
      }
      cropperState.pinchDistance = dist;
    }
  }, { passive: false });

  viewport.addEventListener('touchend', function() {
    cropperState.isDragging = false;
    cropperState.pinchDistance = 0;
  });

  viewport.addEventListener('wheel', function(e) {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.08 : 0.92;
    setCropperZoom(cropperState.scale * factor);
  }, { passive: false });

  function setCropperZoom(newScale) {
    newScale = Math.min(cropperState.maxScale, Math.max(cropperState.minScale * 0.75, newScale));
    const vw = viewport.clientWidth;
    const vh = viewport.clientHeight;

    const centerViewportX = vw / 2;
    const centerViewportY = vh / 2;

    const imgCenterX = (centerViewportX - cropperState.x) / cropperState.scale;
    const imgCenterY = (centerViewportY - cropperState.y) / cropperState.scale;

    cropperState.scale = newScale;
    cropperState.x = centerViewportX - imgCenterX * cropperState.scale;
    cropperState.y = centerViewportY - imgCenterY * cropperState.scale;

    if (slider) slider.value = cropperState.scale.toFixed(4);
    applyCropperTransform();
  }

  if (slider) {
    slider.addEventListener('input', function() {
      setCropperZoom(parseFloat(this.value));
    });
  }

  if (zoomIn) zoomIn.addEventListener('click', () => setCropperZoom(cropperState.scale * 1.15));
  if (zoomOut) zoomOut.addEventListener('click', () => setCropperZoom(cropperState.scale * 0.85));

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      cropperState.scale = cropperState.minScale;
      const vw = viewport.clientWidth;
      const vh = viewport.clientHeight;
      cropperState.x = (vw - cropperState.naturalW * cropperState.scale) / 2;
      cropperState.y = (vh - cropperState.naturalH * cropperState.scale) / 2;
      if (slider) slider.value = cropperState.scale.toFixed(4);
      applyCropperTransform();
    });
  }

  if (applyBtn) {
    applyBtn.addEventListener('click', async function() {
      applyBtn.disabled = true;
      applyBtn.innerHTML = '<span>⏳ Kaydediliyor...</span>';

      try {
        const vw = viewport.clientWidth;
        const vh = viewport.clientHeight;
        const renderedW = cropperState.naturalW * cropperState.scale;
        const scaleRatio = cropperState.naturalW / renderedW;

        const srcX = Math.max(0, -cropperState.x * scaleRatio);
        const srcY = Math.max(0, -cropperState.y * scaleRatio);
        const srcW = Math.min(cropperState.naturalW - srcX, vw * scaleRatio);
        const srcH = Math.min(cropperState.naturalH - srcY, vh * scaleRatio);

        const canvas = document.createElement('canvas');
        canvas.width = 1280;
        canvas.height = 720;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(cropperState.img, srcX, srcY, srcW, srcH, 0, 0, 1280, 720);

        canvas.toBlob(async function(blob) {
          if (!blob) {
            window.showToast?.('Kırpma işlemi başarısız oldu.', 'error');
            applyBtn.disabled = false;
            applyBtn.innerHTML = '<span>✓ Çerçeveyi Kaydet & Uygula</span>';
            return;
          }

          const file = new File([blob], 'thumb_' + Date.now() + '.webp', { type: 'image/webp' });
          const res = await window.CmsClient.uploadPhoto(file);

          if (res && res.success && res.url) {
            const croppedUrl = res.url;
            const projInput = document.getElementById('projImage');
            if (projInput) projInput.value = croppedUrl;

            if (cropperState.pendingFile) {
              window.CmsClient.uploadPhoto(cropperState.pendingFile).then(origRes => {
                if (origRes && origRes.success && origRes.url) {
                  if (!currentModalProjectImages.includes(origRes.url)) {
                    currentModalProjectImages.unshift(origRes.url);
                    renderModalProjectImages();
                  }
                }
              });
            } else if (cropperState.originalUrl && !cropperState.originalUrl.startsWith('blob:')) {
              if (!currentModalProjectImages.includes(cropperState.originalUrl)) {
                currentModalProjectImages.unshift(cropperState.originalUrl);
                renderModalProjectImages();
              }
            }

            renderModalProjectImages();

            if (typeof cropperState.onComplete === 'function') {
              cropperState.onComplete(croppedUrl, cropperState.originalUrl);
            }

            window.showToast?.('Önizleme çerçevesi başarıyla uygulandı!', 'success');
            closeImageCropperModal();
          } else {
            window.showToast?.('Fotoğraf kaydedilemedi.', 'error');
          }

          applyBtn.disabled = false;
          applyBtn.innerHTML = '<span>✓ Çerçeveyi Kaydet & Uygula</span>';
        }, 'image/webp', 0.88);

      } catch (err) {
        console.error('Cropper error:', err);
        window.showToast?.('Hata: ' + err.message, 'error');
        applyBtn.disabled = false;
        applyBtn.innerHTML = '<span>✓ Çerçeveyi Kaydet & Uygula</span>';
      }
    });
  }
}
`;

adminJs += bulletproofCropper;

fs.writeFileSync('js/admin.js', adminJs, 'utf8');
console.log('js/admin.js successfully updated with bulletproof cropper');
